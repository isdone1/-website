const productsData = [
    ['iPhone 5 / 5s', 'classic'], ['iPhone 6 / 6 Plus', 'classic'], ['iPhone 6s / 6s Plus', 'classic'],
    ['iPhone 7 / 7 Plus', 'classic'], ['iPhone 8 / 8 Plus', 'classic'],
    ['iPhone X / XR / XS', 'x', 'IMG_E5416.JPG'], ['iPhone XS Max', 'x'],
    ['iPhone 11', '11'], ['iPhone 11 Pro / Pro Max', '11'],
    ['iPhone 12 / 12 mini', '12', 'IMG_5417.JPG'], ['iPhone 12 Pro / Pro Max', '12', 'IMG_5420.JPG'],
    ['iPhone 13 / 13 mini', '13', 'IMG_E5439.JPG'], ['iPhone 13 Pro / Pro Max', '13', 'IMG_E5445.JPG'],
    ['iPhone 14 / 14 Plus', '14', 'IMG_5425.JPG'], ['iPhone 14 Pro / Pro Max', '14', '5f54608e629a303a900da684f3470510.jpg'],
    ['iPhone 15 / 15 Plus', '15'], ['iPhone 15 Pro / Pro Max', '15', 'IMG_E5444.JPG'],
    ['iPhone 16 / 16 Plus', '16', 'IMG_E5441.JPG'], ['iPhone 16 Pro / Pro Max', '16', 'IMG_E5442.JPG'],
    ['iPhone 17', '17', 'IMG_5421.JPG'], ['iPhone 17 Air', '17'], ['iPhone 17 Pro / Pro Max', '17', 'IMG_E5426.JPG']
];

const menuButton = document.querySelector('#menu');
const navigation = document.querySelector('#navigation');

if (menuButton && navigation) {
    menuButton.addEventListener('click', () => {
        const isOpen = navigation.classList.toggle('open');
        menuButton.setAttribute('aria-expanded', String(isOpen));
        menuButton.setAttribute('aria-label', isOpen ? 'Close menu' : 'Open menu');
    });

    navigation.querySelectorAll('a').forEach((link) => {
        link.addEventListener('click', () => {
            navigation.classList.remove('open');
            menuButton.setAttribute('aria-expanded', 'false');
            menuButton.setAttribute('aria-label', 'Open menu');
        });
    });
}

const productsContainer = document.querySelector('#products');
const searchInput = document.querySelector('#search');
const familyFilter = document.querySelector('#filter');
const resultCount = document.querySelector('#result-count');

if (productsContainer && searchInput && familyFilter && resultCount) {
    function renderProducts() {
        const query = searchInput.value.trim().toLowerCase();
        const family = familyFilter.value;
        const matches = productsData.filter(([name, modelFamily]) =>
            (family === 'all' || modelFamily === family) && name.toLowerCase().includes(query)
        );

        productsContainer.innerHTML = matches.map(([name, , photo]) => {
            const message = encodeURIComponent(`Hello GLORD GADGETS, I want ${name}. Please send me the current price, storage options and availability.`);
            const image = photo ? `assets/${photo}` : 'assets/iphone.svg';
            return `<article class="product-card">
                <div class="product-picture"><img src="${image}" alt="${name}" loading="lazy" onerror="this.onerror=null;this.src='assets/iphone.svg'"></div>
                <div class="product-body">
                    <h3>${name}</h3>
                    <div class="product-tag">Quality device · Price on request</div>
                    <div class="product-price">Price on request<small>Confirm current price and stock on WhatsApp</small></div>
                    <a class="order-link" href="https://wa.me/2349154099158?text=${message}" target="_blank" rel="noopener noreferrer">Order on WhatsApp</a>
                </div>
            </article>`;
        }).join('') || '<p class="empty-state">No matching iPhone found.</p>';

        resultCount.textContent = `${matches.length} ${matches.length === 1 ? 'model' : 'models'}`;
    }

    searchInput.addEventListener('input', renderProducts);
    familyFilter.addEventListener('change', renderProducts);
    renderProducts();
}